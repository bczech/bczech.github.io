#!/usr/bin/env bash
# expression_report.sh: classify genes by stress/control fold change,
# annotate them with gene names, and print a sorted report.
set -euo pipefail

usage() {
    cat >&2 <<USAGE
Usage: expression_report.sh -e EXPR -a ANNOT [-f FOLD] [-h]
  -e EXPR   expression table (required): gene ID, then
            3 control and 3 stress columns
  -a ANNOT  GTF annotation with gene names (required)
  -f FOLD   induction threshold (default 2.0);
            the repression threshold is 1/FOLD
  -h        show this help and exit
USAGE
}

expr="" annot="" fold=2.0
while getopts "e:a:f:h" opt; do
    case "$opt" in
        e) expr="$OPTARG" ;;
        a) annot="$OPTARG" ;;
        f) fold="$OPTARG" ;;
        h) usage; exit 0 ;;
        *) usage; exit 1 ;;
    esac
done
[[ -z "$expr" ]] && { echo "error: -e is required" >&2; usage; exit 1; }
[[ -z "$annot" ]] && {
    echo "error: -a is required" >&2; usage; exit 1
}
[[ ! -s "$expr" ]] && {
    echo "error: '$expr' missing or empty" >&2; exit 1
}
[[ ! -s "$annot" ]] && {
    echo "error: '$annot' missing or empty" >&2; exit 1
}

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

# branch A: gene_id -> gene_name
awk -F'\t' '$3=="gene"{
    g=$9; sub(/.*gene_id "/,"",g); sub(/".*/,"",g)
    n="."
    if ($9 ~ /gene_name/) {
        n=$9; sub(/.*gene_name "/,"",n); sub(/".*/,"",n)
    }
    print g"\t"n
}' "$annot" | sort -k1,1 > "$tmp/names.tsv"

# branch B: fold change per gene
tail -n +2 "$expr" | awk -F'\t' '{
    c = ($2+$3+$4)/3
    s = ($5+$6+$7)/3
    printf "%s\t%.1f\t%.1f\t%.2f\n", $1, c, s, s/c
}' | sort -k1,1 > "$tmp/fc.tsv"

# merge, classify, sort, print
join -t$'\t' -1 1 -2 1 -o '1.1,2.2,1.2,1.3,1.4' \
    "$tmp/fc.tsv" "$tmp/names.tsv" \
  | awk -F'\t' -v up="$fold" 'BEGIN { OFS = "\t"; dn = 1/up }
      { cls = $5>=up ? "induced" : ($5<=dn ? "repressed" : "unchanged")
        print $0, cls }' \
  | sort -t$'\t' -k5,5nr \
  | awk -F'\t' '
      BEGIN { fmt = "%-9s %-7s %9s %9s %7s  %s\n"
              printf fmt, "gene", "name", "control", "stress",
                     "fold", "class" }
      { printf fmt, $1, $2, $3, $4, $5, $6; n[$6]++ }
      END { print ""
            for (c in n) printf "  %s: %d\n", c, n[c] | "sort" }'
