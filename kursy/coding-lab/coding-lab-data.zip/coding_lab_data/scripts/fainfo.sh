#!/usr/bin/env bash
# fainfo.sh: count the sequences in a FASTA file and report
# their mean length, optionally only sequences of MINLEN bp or more.
set -euo pipefail

usage() {
    cat >&2 <<USAGE
Usage: fainfo.sh -i FILE [-m MINLEN] [-h]
  -i FILE    input FASTA file (required)
  -m MINLEN  report only sequences of at least MINLEN bp (default 0)
  -h         show this help and exit
USAGE
}

infile=""
minlen=0
while getopts "i:m:h" opt; do
    case "$opt" in
        i) infile="$OPTARG" ;;
        m) minlen="$OPTARG" ;;
        h) usage; exit 0 ;;
        *) usage; exit 1 ;;
    esac
done

if [[ -z "$infile" ]]; then
    echo "fainfo.sh: an input file is required (-i)" >&2
    usage
    exit 1
fi
if [[ ! -s "$infile" ]]; then
    echo "fainfo.sh: '$infile' is missing or empty" >&2
    exit 1
fi

awk -v min="$minlen" '
    /^>/ { if (name != "" && len >= min) { n++; tot += len }
           name = $0; len = 0; next }
    { len += length($0) }
    END { if (name != "" && len >= min) { n++; tot += len }
          printf "sequences: %d\n", n
          if (n > 0) printf "mean length: %.1f bp\n", tot / n }
' "$infile"
